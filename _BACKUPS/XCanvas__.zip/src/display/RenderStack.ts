type PathRenderable = SolidFill|SolidStroke|GradientFill|GradientStroke|PatternFill|PatternStroke|BitmapFill;
type TextRenderable = SolidTextFill|SolidTextStroke|GradientTextFill|GradientTextStroke|PatternTextFill|PatternTextStroke;
type RenderStackable = PathRenderable|TextRenderable|Path|TextPath

class RenderStack {

  protected _lastPath:Path|TextPath;
  protected _lastFillStroke:FillStroke;

  private rect:SquarePath;
  protected _first:RenderStackElement;
  protected stack:RenderStackElement;
  protected nbStack:number = 0;
  public offsetW:number = 0;
  public offsetH:number = 0;

  public mouse:MouseControler;

  public constructor(){
    this.rect = SquarePath.instance;
    //this.cacheFill = cacheFill;
  }

  public push(renderStackElement:Path|TextPath|FillStroke,mouseEnabled:boolean=true):RenderStackElement{
    var o:RenderStackElement = new RenderStackElement(renderStackElement,mouseEnabled);
    if(!this.stack) this._first = this.stack = o;
    else {
      o.prev = this.stack;
      this.stack.next = o;
      this.stack = o;
    }

    if(renderStackElement instanceof Path || renderStackElement instanceof TextPath) this._lastPath = renderStackElement;
    else if(renderStackElement instanceof FillStroke) this._lastFillStroke = renderStackElement;

    o.init(this._lastPath,this._lastFillStroke);


    return o;
  }


  public update(context:CanvasRenderingContext2D,target:Display2D,mouseX:number=Number.MAX_VALUE,mouseY:number=Number.MAX_VALUE):void{
    let o:RenderStackElement;
    let path:Path;
    let text:TextPath;
    let hitTest:boolean = false;
    let fillStroke:FillStroke;
    o = this._first;
    this.updateBounds(target);
    while (o) {

        //context.beginPath();
        context.save();
        if(o.enabled){
          if(o.isPath) path = o.value as Path
          else if(o.isTextPath) text = o.value as TextPath;
          else {

            if(o.isTextFillStroke){
              (o.value as TextRenderable).apply(context,text,target);
              if(!hitTest && o.mouseEnabled && target.useComplexHitTest) {
                   hitTest = (o.isTextFill && text.isPointInPath(context,mouseX,mouseY)) || (o.isTextStroke && text.isPointInStroke(context,mouseX,mouseY));
              }

            }else{

              fillStroke = o.value as FillStroke;
              (fillStroke as PathRenderable).apply(context,path,target);

               if(!hitTest && o.mouseEnabled && target.useComplexHitTest) {
                   hitTest = (o.isPathFill && path.isPointInPath(context,mouseX,mouseY,(o.value as FillStroke).fillPathRule)) || (o.isPathStroke && path.isPointInStroke(context,mouseX,mouseY));
               }
            }
          }
        }
        o = o.next;
        context.restore();
    }
    //console.log(this.offsetW,this.offsetH)


    if(target.cacheAsBitmap){
      context.save();
      context.globalAlpha = target.realAlpha;
      var rx = this.offsetW/(target.width*target.scaleX);
      var ry = this.offsetH/(target.height*target.scaleY);
      var bd = target.bitmapCache;

      context.scale(1 / (bd.width -this.offsetW*2) , 1 / (bd.height -this.offsetH*2));
      context.translate(-this.offsetW,-this.offsetH);
      context.drawImage(bd,0,0);
      context.restore();
    }


    if(target.mouseIsOver == false && hitTest) target.onMouseOver();
    if(target.mouseIsOver && hitTest == false) target.onMouseOut();

  }

  public updateBounds(target:Display2D):Rectangle2D{
    /*
    it's a copy of "update" without mouse handling, mouse events & rendering update
    */

    let o:RenderStackElement;
    let path:Path;
    let text:TextPath;
    let hitTest:boolean = false;
    let fillStroke:FillStroke;
    o = this._first;

    target.resetBoundsOffsets();

    let offsetW:number = 0;
    let offsetH:number = 0;
    let lineW:number = 0;

    while (o) {
        if(o.enabled){
          if(o.isPath) path = o.value as Path
          else if(o.isTextPath) text = o.value as TextPath;
          else {
              fillStroke = o.value as FillStroke;
              if(fillStroke.offsetW > offsetW) offsetW = fillStroke.offsetW;
              if(fillStroke.offsetH > offsetH) offsetH = fillStroke.offsetH;
              if(fillStroke.lineWidth > lineW) lineW = fillStroke.lineWidth;
          }
        }
        o = o.next;
    }


    var r:Rectangle2D = path.geometry.getBounds(target, (offsetW+lineW) * Math.sqrt(2), (offsetH+lineW) * Math.sqrt(2));
    this.offsetW =lineW + (offsetW) * (Math.sqrt(2)+1);
    this.offsetH =lineW + (offsetH) * (Math.sqrt(2)+1);
    return r;
  }


  public get first():RenderStackElement{return this._first}


  public updateCache(context:CanvasRenderingContext2D,target:Display2D):void{

    let o:RenderStackElement;
    let path:Path;
    let text:TextPath;
    o = this._first;

    while (o) {
        context.save();
        if(o.enabled){
          if(o.isPath) path = o.value as Path
          else if(o.isTextPath) text = o.value as TextPath;
          else {
            if(o.isTextFillStroke) (o.value as TextRenderable).apply(context,text,target);
            else (o.value as PathRenderable).apply(context,path,target);
          }
        }
        o = o.next;
        context.restore();
    }
  }


}
