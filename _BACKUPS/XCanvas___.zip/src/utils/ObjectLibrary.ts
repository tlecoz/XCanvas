class ObjectLibrary {

  private static _instance:ObjectLibrary;

  private objects:any;
  private names:string[];
  private indexByName:number[];

  constructor(){
    if(!ObjectLibrary._instance){
      ObjectLibrary._instance = this;
      this.objects = {};
      this.names = [];
      this.indexByName = [];
    }else{
      throw new Error("ObjectLibrary is a singleton. You must use ObjectLibrary.instance")
    }
  }

  public registerObject(dataType:string,o:any):string{
    let id:number,typeId:number;
    if(!this.objects[dataType]){
      this.indexByName[dataType] = typeId = this.names.length;
      this.names.push(dataType);
      this.objects[dataType] = {
        index:1,
        typeId:typeId,
        elements:[o]
      }
      id = 0;
    }else{
      var obj = this.objects[dataType];
      typeId = obj.typeId;
      id = obj.elements.length;
      obj.elements[id] = o;
    }
    return typeId+"_"+id;
  }

  public static get instance():ObjectLibrary{
    if(!ObjectLibrary._instance) new ObjectLibrary();
    return ObjectLibrary._instance;
  }

  public get dataTypes():string[]{return this.names}
  public getElementsByName(name:string):any[]{ return this.objects[name].elements;}

  public getObjectByRegisterId(registerId:string):any{
    let t:string[] = registerId.split("_");
    return this.objects[this.names[Number(t[0])]].elements[Number(t[1])];
  }

  public static print():void{
    var lib = ObjectLibrary.instance;
    var names:string[] = lib.dataTypes;
    var i:number,len:number = names.length;
    var name:string;
    for(i=0;i<len;i++){
      name = names[i];
      console.log("nb "+name+" = "+lib.getElementsByName(name).length);
    }
  }
  public static printElements(name:string){
    var t = ObjectLibrary.instance.getElementsByName(name);
    var i:number,len:number = t.length;
    for(i=0;i<len;i++) console.log(i," => ",t[i]);
  }

}
