class BlurFilter extends Filter {
  constructor(intensity:number=0){
    super();
    this.radius = intensity;
  }
  public clone():BlurFilter{ return new BlurFilter(this.radius)}
  public get value():string{ return "blur("+this.radius+"+px)"}
}
