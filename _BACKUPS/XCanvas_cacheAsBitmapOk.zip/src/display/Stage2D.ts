class Stage2D extends Group2D {

  protected _canvas:HTMLCanvasElement;
  protected _context:CanvasRenderingContext2D;
  protected _mouseControler:MouseControler;

  constructor(w:number,h:number,appendOnBody:boolean=true){
    super();
    this._stage = this;
    this._canvas = document.createElement("canvas");
    this._canvas.width = w;
    this._canvas.height = h;
    this._context = this._canvas.getContext("2d");
    this._mouseControler = new MouseControler(this._canvas);
    this._canvas.style.position = "absolute";
    if(appendOnBody) document.body.appendChild(this._canvas);
  }

  public get canvas():HTMLCanvasElement{return this._canvas;}
  public get context():CanvasRenderingContext2D{return this._context;}
  public get mouseControler():MouseControler{return this._mouseControler;}
  public get realAlpha():number{return this.alpha;}

  public get realX():number{return this.x};
  public get realY():number{return this.y};
  public get realScaleX():number{return this.scaleX};
  public get realScaleY():number{return this.scaleY};
  public get realRotation():number{return this.rotation};

  public drawElements():void{
    this._canvas.width = this._canvas.width;
    super.update(this._context);
    
  }

}
