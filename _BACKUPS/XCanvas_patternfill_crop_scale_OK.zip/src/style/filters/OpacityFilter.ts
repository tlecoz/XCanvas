class OpacityFilter extends Filter {
  constructor(intensity:number=3){
    super();
    this._intensity = intensity;
  }
  public get value():string{ return "opacity("+this._intensity+"+%)"}
  public clone():OpacityFilter{return new OpacityFilter(this._intensity)}
}
