class TouchSwipe {

  public static NOT_A_SWIPE:number = -2;
  public static NOT_DEFINED_YET:number = -1;
  public static SWIPE_RIGHT:number = 0;
  public static SWIPE_DOWN:number = 1;
  public static SWIPE_LEFT:number = 2;
  public static SWIPE_UP:number = 3;
}
