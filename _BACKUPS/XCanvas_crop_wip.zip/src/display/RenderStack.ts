type PathRenderable = SolidFill|SolidStroke|GradientFill|GradientStroke|PatternFill|PatternStroke|BitmapFill;
type TextRenderable = SolidTextFill|SolidTextStroke|GradientTextFill|GradientTextStroke|PatternTextFill|PatternTextStroke;
type RenderStackable = PathRenderable|TextRenderable|Path|TextPath|BitmapCacheFill

class RenderStack {

  protected _lastFill:FillStroke;
  protected _lastStroke:FillStroke;
  protected cacheFill:BitmapCacheFill;
  private rect:SquarePath;
  protected first:RenderStackElement;
  protected stack:RenderStackElement;
  protected nbStack:number = 0;
  public offsetW:number = 0;
  public offsetH:number = 0;
  //public forceUpdateBounds:boolean = false;
  public mouse:MouseControler;

  public constructor(cacheFill:BitmapCacheFill){
    this.rect = SquarePath.instance;
    this.cacheFill = cacheFill;
  }

  public push(renderStackElement:Path|TextPath|FillStroke,mouseEnabled:boolean=true):RenderStackElement{
    var o:RenderStackElement = new RenderStackElement(renderStackElement,mouseEnabled);
    if(!this.stack) this.first = this.stack = o;
    else {
      o.prev = this.stack;
      this.stack.next = o;
      this.stack = o;
    }

    return o;
  }


  public updateHitTest(context:CanvasRenderingContext2D,target:Display2D,mouseX:number=Number.MAX_VALUE,mouseY:number=Number.MAX_VALUE):void{
    let o:RenderStackElement;
    let path:Path;
    let text:TextPath;
    let hitTest:boolean = false;
    let fillStroke:FillStroke;
    o = this.first;

    while (o) {

        context.beginPath();
        context.save();
        if(o.enabled){
          if(o.isPath) path = o.value as Path
          else if(o.isTextPath) text = o.value as TextPath;
          else {

            if(o.isTextFillStroke){
               //(o.value as TextRenderable).apply(context,text,target);
              if(!hitTest && o.mouseEnabled && target.useComplexHitTest) {
                   hitTest = (o.isTextFill && text.isPointInPath(context,mouseX,mouseY)) || (o.isTextStroke && text.isPointInStroke(context,mouseX,mouseY));
              }

            }else{

              fillStroke = o.value as FillStroke;
             //(fillStroke as PathRenderable).apply(context,path,target);
              //console.log(fillStroke)
               if(!hitTest && o.mouseEnabled && target.useComplexHitTest) {
                   //context.fillStyle = "#ff0000"
                   //context.fill(path.path,fillStroke.fillPathRule);
                   hitTest = (o.isPathFill && path.isPointInPath(context,mouseX,mouseY,(o.value as FillStroke).fillPathRule)) || (o.isPathStroke && path.isPointInStroke(context,mouseX,mouseY));
               }
            }
          }
        }
        o = o.next;
        context.restore();
    }


    if(target.mouseIsOver == false && hitTest) target.onMouseOver();
    if(target.mouseIsOver && hitTest == false) target.onMouseOut();

  }

  public update(context:CanvasRenderingContext2D,target:Display2D,mouseX:number=Number.MAX_VALUE,mouseY:number=Number.MAX_VALUE):void{
    let o:RenderStackElement;
    let path:Path;
    let text:TextPath;
    let hitTest:boolean = false;
    let fillStroke:FillStroke;
    o = this.first;
    this.updateBounds(target);
    while (o) {

        //context.beginPath();
        context.save();
        if(o.enabled){
          if(o.isPath) path = o.value as Path
          else if(o.isTextPath) text = o.value as TextPath;
          else {

            if(o.isTextFillStroke){
              (o.value as TextRenderable).apply(context,text,target);
              if(!hitTest && o.mouseEnabled && target.useComplexHitTest) {
                   hitTest = (o.isTextFill && text.isPointInPath(context,mouseX,mouseY)) || (o.isTextStroke && text.isPointInStroke(context,mouseX,mouseY));
              }

            }else{

              fillStroke = o.value as FillStroke;
              (fillStroke as PathRenderable).apply(context,path,target);

               if(!hitTest && o.mouseEnabled && target.useComplexHitTest) {
                   hitTest = (o.isPathFill && path.isPointInPath(context,mouseX,mouseY,(o.value as FillStroke).fillPathRule)) || (o.isPathStroke && path.isPointInStroke(context,mouseX,mouseY));
               }
            }
          }
        }
        o = o.next;
        context.restore();
    }
    //console.log(this.offsetW,this.offsetH)


    if(target.cacheAsBitmap){
      context.save();
      context.globalAlpha = target.realAlpha;
      var rx = this.offsetW/(target.width*target.scaleX);
      var ry = this.offsetH/(target.height*target.scaleY);
      var bd = target.bitmapCache;

      context.scale(1 / (bd.width -this.offsetW*2) , 1 / (bd.height -this.offsetH*2));
      context.translate(-this.offsetW,-this.offsetH);
      context.drawImage(bd,0,0);
      context.restore();
    }


    if(target.mouseIsOver == false && hitTest) target.onMouseOver();
    if(target.mouseIsOver && hitTest == false) target.onMouseOut();

  }

  public updateBounds(target:Display2D):void{
    /*
    it's a copy of "update" without mouse handling, mouse events & rendering update
    */

    let o:RenderStackElement;
    let path:Path;
    let text:TextPath;
    let hitTest:boolean = false;
    let fillStroke:FillStroke;
    o = this.first;

    target.resetBoundsOffsets();

    let offsetW:number = 0;
    let offsetH:number = 0;
    let lineW:number = 0;

    while (o) {
        if(o.enabled){
          if(o.isPath) path = o.value as Path
          else if(o.isTextPath) text = o.value as TextPath;
          else {
              fillStroke = o.value as FillStroke;
              if(fillStroke.offsetW > offsetW) offsetW = fillStroke.offsetW;
              if(fillStroke.offsetH > offsetH) offsetH = fillStroke.offsetH;
              if(fillStroke.lineWidth > lineW) lineW = fillStroke.lineWidth;
          }
        }
        o = o.next;
    }


    var r:Rectangle2D = path.geometry.getBounds(target, (offsetW+lineW) * Math.sqrt(2), (offsetH+lineW) * Math.sqrt(2));
    //this.offsetW =(offsetW+lineW) * (Math.sqrt(2)+1);
    //this.offsetH =(offsetH+lineW) * (Math.sqrt(2)+1);

    this.offsetW =lineW + (offsetW) * (Math.sqrt(2)+1);
    this.offsetH =lineW + (offsetH) * (Math.sqrt(2)+1);
  }



  public updateTargetAsCache(context:CanvasRenderingContext2D,target:Display2D,mouseX:number,mouseY:number):void{
    context.save();
    //context.beginPath();

    var bmpFill = this.cacheFill;

    var w1 = bmpFill.width; // * target.scaleX;
    var h1 = bmpFill.height; // * target.scaleY;
    var sx = (bmpFill.width ) / ((target.width+ this.offsetW*2)*target.scaleX);
    var sy = (bmpFill.height) / ((target.height+this.offsetH*2)*target.scaleY) ;



    context.translate(this.offsetW/target.scaleX,this.offsetH/target.scaleY)


    context.scale((target.width)*target.scaleX ,(target.height)*target.scaleY)

    let hitTest:boolean =false;
    if(!hitTest && target.mouseEnabled ) {

        context.fillStyle = "rgba(255,0,0,0.5)"
        context.fill(this.rect.path);
        hitTest = this.rect.isPointInPath(context,mouseX,mouseY,"nonzero") ;
    }

    if(target.mouseIsOver == false && hitTest) target.onMouseOver();
    if(target.mouseIsOver && hitTest == false) target.onMouseOut();



    context.restore();

    context.save();
    //context.beginPath();
    //bmpFill.apply(context,this.rect,target);
    context.restore();
  }




  public updateCache(context:CanvasRenderingContext2D,target:Display2D):void{

    /*
    it's a copy of "update" without mouse handling & mouse events
    */

    let o:RenderStackElement;
    let path:Path;
    let text:TextPath;
    let hitTest:boolean = false;
    let fillStroke:FillStroke;
    o = this.first;
    target.resetBoundsOffsets();
    let offsetW:number = 0;
    let offsetH:number = 0;
    let lineW:number = 0;

    while (o) {

        context.save();
        //context.beginPath();
        if(o.enabled){
          if(o.isPath) path = o.value as Path
          else if(o.isTextPath) text = o.value as TextPath;
          else {
            if(o.isTextFillStroke){
               (o.value as TextRenderable).apply(context,text,target);
            }else{
              fillStroke = o.value as FillStroke;
              if(fillStroke.offsetW > offsetW) offsetW = fillStroke.offsetW;
              if(fillStroke.offsetH > offsetH) offsetH = fillStroke.offsetH;
              if(fillStroke.lineWidth > lineW) lineW = fillStroke.lineWidth;
              (fillStroke as PathRenderable).apply(context,path,target);
            }
          }
        }
        o = o.next;
        context.restore();
    }

  }


}
