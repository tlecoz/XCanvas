class Matrix2D extends EventDispatcher {

  public static IDENTITY:DOMMatrix = new DOMMatrix("matrix(1, 0, 0, 1, 0, 0)");

  public x:number = 0;
  public y:number = 0;
  public xAxis:number = 0;
  public yAxis:number = 0;
  public rotation:number = 0;
  public scaleX:number = 1;
  public scaleY:number = 1;
  public width:number = 1;
  public height:number = 1;

  public offsetW:number = 0;
  public offsetH:number = 0;

  private _screenX:number;
  private _screenY:number;

  protected matrix:DOMMatrix;

  protected savedMatrixs:any;

  constructor(){
      super();
      this.savedMatrixs = [];
      this.matrix = new DOMMatrix();
  }

  public save():void{
    let o:any = this.savedMatrixs,next:any = null;
    if(o) next = o;
    var obj:any = {
      matrix:this.matrix.toString(),
      next:next
    }
    this.savedMatrixs = obj;
  }
  public restore():void{
    this.setMatrixValue(this.savedMatrixs.matrix);
    this.savedMatrixs = this.savedMatrixs.next;
  }
  public get realWidth():number{
    //must be overrided
    return this.width;
  }
  public get realHeight():number{
    //must be overrided
    return this.height;
  }
  public clone():Matrix2D{
      var m:Matrix2D = new Matrix2D();
      m.x = this.x;
      m.y = this.y;
      m.rotation = this.rotation;
      m.scaleX = this.scaleX;
      m.scaleY = this.scaleY;
      m.xAxis = this.xAxis;
      m.yAxis = this.yAxis;
      m.width = this.width;
      m.height = this.height;
      m.setMatrixValue(this.matrix.toString());
      return m;
  }

  public applyTransform():DOMMatrix{
    const m:DOMMatrix = this.matrix;

    m.translateSelf(this.x  ,this.y  );
    m.rotateSelf(this.rotation);
    m.translateSelf(-this.xAxis*this.scaleX ,-this.yAxis*this.scaleY)

    m.scaleSelf(this.width*this.scaleX,this.height*this.scaleY);

    //var p:DOMPoint = this.domMatrix.transformPoint(new DOMPoint(0,0));
    //this._screenX = p.x + this.xAxis;
    //this._screenY = p.y + this.yAxis;

    return m;
  }

  //public get screenX():number{ return this._screenX; }
  //public get screenY():number{ return this._screenY; }

  public setMatrixValue(s:string="matrix(1, 0, 0, 1, 0, 0)"):DOMMatrix{return this.matrix.setMatrixValue(s);}
  public translate(x:number,y:number):DOMMatrix{ return this.matrix.translateSelf(x,y); }
  public rotate(angle:number):DOMMatrix{ return this.matrix.rotateSelf(angle); }
  public scale(x:number,y:number):DOMMatrix{ return this.matrix.scaleSelf(x,y); }

  public invert():DOMMatrix{return this.matrix.invertSelf()}
  public rotateFromVector(x:number,y:number):DOMMatrix{ return this.matrix.rotateFromVectorSelf(x,y) }
  public multiply(m:Matrix2D):void{  this.matrix.multiplySelf(m.domMatrix); }
  public preMultiply(m:Matrix2D):void{  this.matrix.preMultiplySelf(m.domMatrix); }
  public identity():void{  this.matrix.setMatrixValue("matrix(1, 0, 0, 1, 0, 0)"); }

  public get domMatrix():DOMMatrix{return this.matrix}
}
