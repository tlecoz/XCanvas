type Fillable = Path|TextPath;

class FillStroke {


  public fillPathRule:"nonzero"|"evenodd" = "nonzero";
  protected styleType:"fillStyle"|"strokeStyle";

  public alpha:number=1;
  public lineStyle:LineStyle = null;
  public textStyle:TextStyle = null;
  public filter:CssFilter = null;
  protected _filters:FilterStack = null;
  public needsUpdate:boolean = true;
  public static radian:number = Math.PI/180;

  public offsetW:number = 0;
  public offsetH:number = 0;
  public dirty:boolean = true;

  constructor(){

    this._filters = new FilterStack();
  }

  public apply(context:CanvasRenderingContext2D,path:Fillable,target:Display2D):void{
    if(target.fillStrokeDrawable) context.globalAlpha = this.alpha * target.realAlpha;


    let css:FilterStack = this._filters;
    if(css){
      this.dirty = css.dirty;
      if(target.fillStrokeDrawable) context.filter = css.value;
      this.offsetW = css.boundOffsetW;
      this.offsetH = css.boundOffsetH;
    }else{
      context.filter = "none";
    }
  }

  public get filters():FilterStack{return this._filters;}
  public get realOffsetW():number{return this.offsetW + this.lineWidth}
  public get realOffsetH():number{return this.offsetH + this.lineWidth}

  public get lineWidth():number{
    if(null == this.lineStyle) return 0;
    return this.lineStyle.lineWidth;
  }



}
