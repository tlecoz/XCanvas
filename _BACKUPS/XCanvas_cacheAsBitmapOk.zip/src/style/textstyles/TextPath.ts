class TextPath {

  public text:string;

  constructor(text:string){
    this.text = text;
  }

  public isPointInPath(context:CanvasRenderingContext2D,px:number,py:number):boolean{
    return false;
  }
  public isPointInStroke(context:CanvasRenderingContext2D,px:number,py:number):boolean{
    return false;
  }
}
