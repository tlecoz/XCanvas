class DisplayObjectEvents {
  public static ADDED = "ADDED";
  public static ADDED_TO_STAGE = "ADDED_TO_STAGE";
  public static REMOVED = "REMOVED";
  public static REMOVED_FROM_STAGE = "REMOVED_FROM_STAGE";
  public static MOVE = "MOVE";
}
