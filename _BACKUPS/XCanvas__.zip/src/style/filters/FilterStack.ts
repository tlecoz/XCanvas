class FilterStack implements IDirty {

  protected first:Filter;
  protected last:Filter;
  protected _value:string;
  public dirty:boolean = true;
  public boundOffsetW:number = 0;
  public boundOffsetH:number = 0;



  //public cacheAsBitmap:boolean = false;


  constructor(){

  }

  public clear():void{
    let f:Filter = this.first;
    while(f){
      f.clear();
      f = f.next;
    }
  }

  public clone(cloneFilters:boolean=false):FilterStack{
    let f:any = this.first;
    const s:FilterStack = new FilterStack();
    while(f){
      if(cloneFilters) s.add(f.clone())
      else s.add(f);
    }
    return s;
  }


  public get value():string{

    if(this.dirty){
      //console.log(this.dirty)
      let v:string = "";
      let f:Filter = this.first;
      let w:number = 0,h:number = 0;
      while(f){
        v = v + f.value+" ";
        if(f.boundOffsetX > w) w = f.boundOffsetX;
        if(f.boundOffsetY > h) h = f.boundOffsetY;
        f = f.next;
      }
      this.boundOffsetW = w;
      this.boundOffsetH = h;
      this._value = v;
      this.dirty = false;
    }
    return this._value;
  }



  public add(filter:Filter):FilterStack{
    if(!this.first) this.first = filter;
    if(this.last) this.last.next = filter;
    this.last = filter;
    filter.addDirtyEventTarget(this);
    return this;
  }



}
