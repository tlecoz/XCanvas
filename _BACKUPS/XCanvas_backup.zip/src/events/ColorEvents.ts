class ColorEvents {
  //SOLID COLOR EVENTS
public static CHANGED = "CHANGED";
public static ALPHA_CHANGED = "CHANGED";
public static RED_CHANGED = "CHANGED";
public static GREEN_CHANGED = "CHANGED";
public static BLUE_CHANGED = "CHANGED";

//GRADIENT COLOR EVENTS
public static GRADIENT_CHANGED = "CHANGED";
}
