class KeyboardEvents {
  public static KEY_DOWN = "KEY_DOWN";
  public static KEY_UP = "KEY_UP";
  public static CHANGED = "CHANGED";
}
