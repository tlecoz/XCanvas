

class RenderStackElement {

  public value:FillStroke|Path|TextPath|Shape;
  public enabled:boolean = true
  public mouseEnabled:boolean;
  public path:Path|TextPath = null;


  public isShape:boolean;
  public isPath:boolean;
  public isTextPath:boolean;
  public isPathFill:boolean;
  public isPathStroke:boolean;
  public isTextFill:boolean;
  public isTextStroke:boolean;
  public isTextFillStroke:boolean;
  public isPathFillStroke:boolean;
  public isStroke:boolean;

  protected _lastPath:Path|TextPath = null;
  protected _lastFillStroke:FillStroke = null;


  constructor(element:FillStroke|Path|TextPath|Shape,mouseEnabled:boolean=true){
    this.value = element;
    this.mouseEnabled = mouseEnabled;

    this.isShape = this.value instanceof Shape;
    if(this.isShape) return;


    this.isPath = this.value instanceof Path;
    this.isTextPath = this.value instanceof TextPath;
    if(this.isPath || this.isTextPath) return;


    this.isPathFill = this.value instanceof SolidFill ||
                      this.value instanceof GradientFill ||
                      this.value instanceof PatternFill ||
                      this.value instanceof BitmapFill || this.value instanceof BitmapCacheFill;

    this.isPathStroke = this.value instanceof SolidStroke ||
                         this.value instanceof GradientStroke ||
                         this.value instanceof PatternStroke ;

    this.isTextFill = this.value instanceof SolidTextFill ||
                     this.value instanceof GradientTextFill ||
                     this.value instanceof PatternTextFill ;

    this.isTextStroke = this.value instanceof SolidTextStroke ||
                        this.value instanceof GradientTextStroke ||
                        this.value instanceof PatternTextStroke ;

    this.isTextFillStroke =  this.value instanceof SolidTextFill ||
                             this.value instanceof GradientTextFill ||
                             this.value instanceof PatternTextFill ||
                             this.value instanceof SolidTextStroke ||
                             this.value instanceof GradientTextStroke ||
                             this.value instanceof PatternTextStroke;

    this.isPathFillStroke = this.value instanceof SolidStroke ||
                            this.value instanceof GradientStroke ||
                            this.value instanceof PatternStroke ||
                            this.value instanceof SolidFill ||
                            this.value instanceof GradientFill ||
                            this.value instanceof PatternFill ||
                            this.value instanceof BitmapFill;

    this.isStroke = this.isTextStroke || this.isPathStroke;

  }

  public get lastPath():Path|TextPath{return this._lastPath}
  public get lastFillStroke():FillStroke{return this._lastFillStroke}



  public clone():RenderStackElement{
    var o:RenderStackElement = new RenderStackElement(this.value,this.mouseEnabled);
    o.init(this._lastPath,this._lastFillStroke);
    return o;
  }

  public init(lastPath:Path|TextPath,lastFillStroke:FillStroke):void{
    this._lastPath = lastPath;
    this._lastFillStroke = lastFillStroke;
  }



}
