class GrayscaleFilter extends Filter {
  constructor(intensity:number=0){
    super();
    this._intensity = intensity;
  }
  public clone():GrayscaleFilter{ return new GrayscaleFilter(this._intensity)}
  public get value():string{ return "grayscale("+this._intensity+"+%)"}
}
