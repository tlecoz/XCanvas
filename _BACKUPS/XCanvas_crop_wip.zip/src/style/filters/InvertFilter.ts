class InvertFilter extends Filter {
  constructor(intensity:number=0){
    super();
    this._intensity = intensity;
  }
  public get value():string{ return "invert("+this._intensity+"+%)"}
  public clone():InvertFilter{return new InvertFilter(this._intensity)}
}
