class BitmapCache extends Display2D {

  private _bd:BitmapData;
  private target:Display2D;
  constructor(target:Display2D){
    super(target.width,target.height);
    this._bd = new BitmapData(target.width,target.height);
    this.target = target;
    this.stack(new BitmapCacheFill(this._bd));
  }
  public get bd():BitmapData{return this._bd}

  public update(context:CanvasRenderingContext2D):void{
    this.identity();

    this.width = this.bd.width;
    this.height = this.bd.height;

    context.save();
    this.renderStack.updateCache(this._bd.context,this.target);


    this.x = this.target.x;
    this.y = this.target.y;

    if(this.target.parent) this.multiply(this.target.parent);
    this.currentTransform = this.applyTransform();
    (context as any).setTransform(this.currentTransform);
    //this.renderStack.update(context,this.target,this.target.mouse.x,this.target.mouse.y);
    context.restore();
  }



}
