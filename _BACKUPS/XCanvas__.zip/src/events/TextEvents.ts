class TextEvents {
  public static CHANGED = "CHANGED";
  public static FONT_LOADED = "FONT_LOADED";
}
