class PatternStroke extends Pattern {

  constructor(source:BitmapData|CanvasImageSource,crop:boolean=true,applyTargetScale:boolean=false){
    super(source,crop,applyTargetScale)
    this.styleType = "strokeStyle";
  }

  public apply(context:CanvasRenderingContext2D,path:Path,target:Display2D):void{

    if(this.lineStyle) this.lineStyle.apply(context,path,target);
    super.apply(context,path,target);
    if(target.fillStrokeDrawable) context.stroke(path.path);

  }
}
