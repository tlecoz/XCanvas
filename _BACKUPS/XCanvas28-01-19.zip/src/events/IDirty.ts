interface IDirty {
  dirty:boolean;
}
