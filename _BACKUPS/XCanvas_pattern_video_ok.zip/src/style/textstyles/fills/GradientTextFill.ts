class GradientTextFill extends Gradient {

  constructor(textStyle:TextStyle,gradient:GradientColor,isLinear:boolean=true){
    super(gradient,isLinear)
    this.styleType = "fillStyle";
    this.textStyle = textStyle;
  }

  public apply(context:CanvasRenderingContext2D,path:TextPath,target:Display2D):void{

    this.textStyle.apply(context,path,target);
    super.apply(context,path,target);
    if(target.fillStrokeDrawable) context.fillText(path.text,this.textStyle.offsetX/target.width,this.textStyle.offsetY/target.height);

  }
}
