class Group2D extends Display2D {




  protected _numChildren:number = 0;
  protected _children:Display2D[];

  constructor(){
    super(1,1);

  

    this._children = [];
  }





  public setStage(stage:Stage2D){
    super.setStage(stage);
    let i:number,nb:number = this._numChildren;
    for(i=0;i<nb;i++) this._children[i].setStage(stage);
  }
  public appendChild(element:Display2D):Display2D{
    this._children[this._numChildren++] = element;
    element.parent = this;
    this.setStage(this.stage);
    return element;
  }
  public removeChild(element:Display2D):Display2D{
    const id = this._children.lastIndexOf(element);
    if(id < 0) return null;
    this._children.splice(id,1);
    this._numChildren--;
    element.parent = null;
    this.setStage(null);
    return element;
  }

  public get numChildren():number{return this._numChildren;}
  public get children():Display2D[]{return this._children;}

  public update(context:CanvasRenderingContext2D):DOMMatrix{

    let alpha:number = this.alpha;
    const parent:Group2D = this.parent;
    const children:Display2D[] = this.children;
    this.identity();
    if(parent) this.multiply(parent);

    const m:DOMMatrix = this.applyTransform();


    context.save();



    let i:number,nb:number = this._numChildren;
    for(i=0;i<nb;i++) children[i].update(context);

    context.restore();

    return m;
  }

}
