class GradientFill extends Gradient {

  constructor(gradient:GradientColor,isLinear:boolean=true){
    super(gradient,isLinear)
    this.styleType = "fillStyle";
    
  }

  public apply(context:CanvasRenderingContext2D,path:Path,target:Display2D):void{

    super.apply(context,path,target);
    if(target.fillStrokeDrawable) context.fill(path.path,this.fillPathRule);

  }
}
