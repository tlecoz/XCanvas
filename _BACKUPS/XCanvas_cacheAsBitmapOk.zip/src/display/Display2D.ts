
type FillType = string|CanvasGradient|CanvasPattern;

class Display2D extends Matrix2D {

  private static display2dIndex:number = 0;

  public static MOUSE_OVER:string = "MOUSE_OVER";
  public static MOUSE_OUT:string = "MOUSE_OUT";
  public static CLICK:string = "CLICK";



  public static pathManager:Path = new Path();


  protected cacheBd:BitmapData;
  protected _cacheAsBitmap:boolean = false;
  protected _stage:Stage2D;



  protected cacheFill:BitmapCacheFill;
  public renderStack:RenderStack;

  public width:number = 1;
  public height:number = 1;
  public alpha:number = 1;

  public inverseW:number = 1;//used for filling process;
  public inverseH:number = 1;//used for filling process;
  public strokeAfterFill:boolean = true;

  protected mouse:MouseControler;
  public mouseIsOver:boolean = false;
  public mouseEnabled:boolean = true;
  public useBasicHitTest:boolean = false;


  public parent:Group2D;
  protected render:Function;

  public currentTransform:DOMMatrix;

  protected _bounds:Rectangle2D;
  private _display2dName:string



  constructor(w:number,h:number){
    super();
    this._display2dName = "o"+(Display2D.display2dIndex++);
    this.width = w;
    this.height = h;
    this.cacheBd = new BitmapData(w,h);
    this.cacheFill = new BitmapCacheFill(this.cacheBd);
    this.renderStack = new RenderStack(this.cacheFill);
    this._bounds = new Rectangle2D(0,0,w,h);

    this.cacheBd.needsUpdate = true;


    //this.render = Display2D.renderPath;
  }

  /*

     bitmap to geometry

    cacheAsBitmap




    //----------------

    faire en sorte qu'on puisse pusher une RenderStack dans une RenderStack

    gérer les stack de
      - globalCompositeOperation
      - pixel manipulation

    fx basé sur une renderstack
       - tint --> source + globalCompositeOperation +(SquarePath + Fill)

  */

  public get fillStrokeDrawable():boolean{ return this._cacheAsBitmap == false || this.cacheBd.needsUpdate == true; }

  public get display2dName():string{return this._display2dName}
  public get useComplexHitTest():boolean {return this.useBasicHitTest == false && this.mouseEnabled}

 public setStage(stage:Stage2D){
   this._stage = stage;
   if(stage) this.mouse = stage.mouseControler;
   else this.mouse = null;

 }
 public get stage():Stage2D{ return this._stage;}

 public align(displayAlign:Pt2D = Align.CENTER):void{
   this.xAxis = this.width * displayAlign.x;
   this.yAxis = this.height * displayAlign.y;
 }




 public stack(renderStackElement:RenderStackable):RenderStackElement{
   return this.renderStack.push(renderStackElement);
 }





  public get bitmapCache():BitmapData{ return this.cacheBd;}
  public get cacheAsBitmap():boolean{ return this._cacheAsBitmap;}
  public set cacheAsBitmap(b:boolean){
      this._cacheAsBitmap = b;
      if(b) this.updateCacheWithoutRotation();

  }
  public updateCache():BitmapData{
    const bitmapCache:BitmapData = this.bitmapCache;
    const bdContext:CanvasRenderingContext2D = bitmapCache.context;
    const matrix = new DOMMatrix().translate(-this.bounds.x,-this.bounds.y,0).multiply(this.currentTransform);

    this.renderStack.updateBounds(this);

    this.bitmapCache.width = this.bounds.width;
    this.bitmapCache.height = this.bounds.height;

    bdContext.save();
    (bdContext as any).setTransform(matrix)
    this.renderStack.updateCache(bdContext,this);
    bdContext.restore();
    bitmapCache.needsUpdate = false;
    return bitmapCache;
  }
  public updateCacheWithoutRotation():BitmapData{
    const bitmapCache:BitmapData = this.bitmapCache;
    const bdContext:CanvasRenderingContext2D = bitmapCache.context;
    const renderStack:RenderStack = this.renderStack;
    const w:number = this.width * this.scaleX;
    const h:number = this.height * this.scaleY;
    bitmapCache.needsUpdate = true;
    renderStack.updateBounds(this);
    //console.log(renderStack.offsetW)
    this.bitmapCache.width = w + renderStack.offsetW*2;
    this.bitmapCache.height = h + renderStack.offsetH*2;
    bdContext.save();
    (bdContext as any).setTransform(new DOMMatrix().translate(renderStack.offsetW,renderStack.offsetH).scale(w,h));
    renderStack.updateCache(bdContext,this);
    bdContext.restore();
    bitmapCache.needsUpdate = false;
    return bitmapCache;
  }


  public get bounds():Rectangle2D{return this._bounds;}

  public get realAlpha():number{return this.parent.realAlpha * this.alpha;}
  public get realX():number{return this.parent.realX + this.x};
  public get realY():number{return this.parent.realY + this.y};
  public get realScaleX():number{return this.parent.realScaleX *this.scaleX};
  public get realScaleY():number{return this.parent.realScaleY * this.scaleY};
  public get realRotation():number{return this.parent.realRotation + this.rotation};



  public onMouseOver():void{
    this.mouseIsOver = true;
    this.dispatchEvent(Display2D.MOUSE_OVER);
  }
  public onMouseOut():void{
    this.mouseIsOver = false;
    this.dispatchEvent(Display2D.MOUSE_OUT);
  }

  public resetBoundsOffsets():void{
    this.offsetW = this.offsetH = 0;
  }


  private applyCacheTransform():DOMMatrix{
    const m:DOMMatrix = this.matrix;
    const bd:BitmapData = this.cacheBd;
    const ox = this.renderStack.offsetW ;
    const oy = this.renderStack.offsetH ;

    m.translateSelf(this.x,this.y);
    m.rotateSelf(this.rotation);
    m.translateSelf(-this.xAxis*this.scaleX-ox,-this.yAxis*this.scaleY-oy)
    m.scaleSelf((this.width * this.scaleX + ox*2) / bd.width,(this.height * this.scaleY + oy*2) / bd.height);

    return m;
  }


  public update(context:CanvasRenderingContext2D):void{
    this.identity();

    this.inverseW = 1/this.width;
    this.inverseH = 1/this.height;

    context.save();

    //
    //console.log(this.cacheAsBitmap);



    if(this.parent) this.multiply(this.parent);



    if(this.cacheAsBitmap){






      //context.globalAlpha = this.realAlpha
      if(this.cacheBd.needsUpdate){
        this.updateCacheWithoutRotation();
        this.cacheBd.needsUpdate = false;
      }


      /*
      this.currentTransform = this.applyCacheTransform();
      (context as any).setTransform(this.currentTransform);
      this.renderStack.updateTargetAsCache(context,this,this.mouse.x,this.mouse.y);
      */

    }

    this.currentTransform = this.applyTransform();
    (context as any).setTransform(this.currentTransform);
    this.renderStack.update(context,this,this.mouse.x,this.mouse.y);



    //
    context.restore();

  }



}
