class Pattern extends FillStroke {

  protected bd:BitmapData;
  protected matrix:Matrix2D;

  public dirty:boolean = true;
  protected dirtyMatrix:boolean = true;
  protected patternCanvas:CanvasPattern;
  protected canvas:HTMLCanvasElement;

  protected center:boolean;
  protected targetW:number;
  protected targetH:number;
  protected imageBmp:ImageBitmap=null;
  protected rotationInDegree:number=0;
  public onImageLoaded:Function;

  private _crop:boolean = true;

  constructor(bd:BitmapData,centerInto:boolean=true){
    super()

    this.bd = bd;
    var th = this;
    this.onImageLoaded = function(e:BitmapData){
      th.imageBmp = null;
      //th.bd.createImageBitmap().then((bmp)=> th.imageBmp = bmp);
      th.dirty = th.dirtyMatrix = true;
    }
    bd.addEventListener(BitmapData.IMAGE_LOADED,this.onImageLoaded)
    this.matrix = new Matrix2D();
    this.canvas = bd.htmlCanvas;
    this.center = centerInto;
  }

  public get crop():boolean{return this._crop;}
  public set crop(b:boolean){
    if(this._crop != b){
      this.dirty = this.dirtyMatrix = true;
      this._crop = b;
    }
  }

  public clone(cloneMedia:boolean=false,cloneLineStyle:boolean=true,cloneTextStyle:boolean=true,cloneTextLineStyle:boolean=true):Pattern{
    var o:Pattern;
    if(!cloneMedia) o = new Pattern(this.bd);
    else o = new Pattern(this.bd.clone());

    o.mat.x = this.matrix.x;
    o.mat.y = this.matrix.y;
    o.mat.scaleX = this.matrix.scaleX;
    o.mat.scaleY = this.matrix.scaleY;
    o.mat.rotation = this.matrix.rotation;
    o.mat.width = this.matrix.width;
    o.mat.height = this.matrix.height;
    o.mat.setMatrixValue(this.matrix.toString());

    o.fillPathRule = this.fillPathRule;
    o.styleType = this.styleType;
    if(this.lineStyle){
      if(cloneLineStyle) o.lineStyle = this.lineStyle.clone()
      else o.lineStyle = this.lineStyle;
    }
    if(this.textStyle){
      if(cloneTextStyle) o.textStyle = this.textStyle.clone(cloneTextLineStyle)
      else o.textStyle = this.textStyle;
    }
    o.alpha = this.alpha;

    return o;
  }

  public get mat():Matrix2D{return this.matrix}


  public get bitmapData():BitmapData{return this.bd;}
  public set bitmapData(n:BitmapData){
    if(n != this.bd){
      if(this.bd) this.bd.removeEventListener(BitmapData.IMAGE_LOADED,this.onImageLoaded);
      this.bd = n;
      this.bd.addEventListener(BitmapData.IMAGE_LOADED,this.onImageLoaded);
      this.canvas = this.bd.htmlCanvas;
      this.dirty = true;
    }
  }

  public get centerInto():boolean{return this.center;}
  public set centerInto(n:boolean){
    if(n != this.center){
      this.center = n;
      this.dirtyMatrix = true;
    }
  }

  public get targetWidth():number{return this.targetW;}
  public set targetWidth(n:number){
    if(n != this.targetW){
      this.targetW = n;
      this.dirtyMatrix = true;
    }
  }
  public get targetHeight():number{return this.targetW;}
  public set targetHeight(n:number){
    if(n != this.targetH){
      this.targetH = n;
      this.dirtyMatrix = true;
    }
  }

  public get x():number{return this.matrix.x;}
  public set x(n:number){
    if(this.x != n){
      this.matrix.x = n;
      this.dirtyMatrix = true;
    }
  }

  public get y():number{return this.matrix.y;}
  public set y(n:number){
    if(this.y != n){
      this.matrix.y = n;
      this.dirtyMatrix = true;
    }
  }


  public get scaleX():number{return this.matrix.scaleX;}
  public set scaleX(n:number){
    if(this.scaleX != n){
      this.matrix.scaleX = n;
      this.dirtyMatrix = true;
    }
  }


  public get scaleY():number{return this.matrix.scaleY;}
  public set scaleY(n:number){
    if(this.scaleY != n){
      this.matrix.scaleY = n;
      this.dirtyMatrix = true;
    }
  }


  public get rotation():number{return this.matrix.rotation;}
  public set rotation(n:number){
    if(this.rotation != n){
      this.rotationInDegree = n ;
      this.matrix.rotation = n ;
      this.dirtyMatrix = true;
    }
  }


  public apply(context:CanvasRenderingContext2D,path:Fillable,target:Display2D):void{

    const canvas:HTMLCanvasElement = this.canvas;

    if(this.dirty){//} && this.imageBmp != null){
      //this.patternCanvas = context.createPattern(this.imageBmp as any,"repeat");
      this.patternCanvas = context.createPattern(this.canvas as any,"repeat");
      this.dirty = false;
    }

    if(!this.patternCanvas) return;

    this.targetW = target.width;
    this.targetH = target.height;

    let w = canvas.width;
    let h = canvas.height;
    let tw = target.width;
    let th = target.height

    if(this.dirtyMatrix){
      this.matrix.identity();

      let cropRatio:number = 1;
      let sx = this.scaleX,sy = this.scaleY;
      if(this.crop){


        let s = tw / w;
        w *= s;
        h *= s;
        if(h<th){
          s = th/h;
          w *= s;
          h *= s;
        }


        sx *= w / canvas.width;
        sy *= w / canvas.width;

      }

      //console.log(this.canvas.width)

      this.matrix.scale(sx*target.scaleX * target.inverseW  , sy*target.scaleY * target.inverseH );
      //

      if(this.centerInto){
         this.matrix.translate(tw*0.5 * target.scaleX / sx, th*0.5 * target.scaleY/sy);
         this.matrix.rotate(this.rotation / FillStroke.radian)

         this.matrix.translate(tw*0.5 * target.scaleX / sx, th*0.5 * target.scaleY/sy);
         //this.matrix.translate((tw-w)*0.5,(th-h)*0.5);
      }else{
        this.matrix.rotate(this.rotation / FillStroke.radian)
      }
      //else this.matrix.translate()
      console.log(this.x,this.y);
      this.matrix.translate(this.x,this.y);
      this.dirtyMatrix = false;
    }


    super.apply(context,path,target);

    let pattern:CanvasPattern = this.patternCanvas;
    pattern.setTransform(this.matrix.domMatrix)
    context[this.styleType] = pattern;

  }


}
