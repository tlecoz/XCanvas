class RectBounds {

  public minX:number = Number.MAX_VALUE;
  public minY:number = Number.MAX_VALUE;
  public maxX:number = Number.MIN_VALUE;
  public maxY:number = Number.MIN_VALUE;
  protected points:Pt2D[];
  protected nbPoint:number;

  constructor(){
    this.points = [];
    this.nbPoint = 0;
    this.reset();
  }

  public reset():void{
    this.minX = Number.MAX_VALUE;
    this.minY = Number.MAX_VALUE;
    this.maxX = Number.MIN_VALUE;
    this.maxY = Number.MIN_VALUE;
  }
  public addPoint(px:number,py:number){
    if(px <= this.minX) this.minX = px;
    if(px >= this.maxX) this.maxX = px;
    if(py <= this.minY) this.minY = py;
    if(py >= this.maxY) this.maxY = py;
    this.points[this.nbPoint++] = new Pt2D(px,py);
  }
  public addRect(minX:number,minY:number,maxX:number,maxY:number){
      if(minX <= this.minX) this.minX = minX;
      if(maxX >= this.maxX) this.maxX = maxX;
      if(minY <= this.minY) this.minY = minY;
      if(maxY >= this.maxY) this.maxY = maxY;
  }
  public drawBounds = function(context2D:CanvasRenderingContext2D){
      context2D.save();
      context2D.beginPath();
      context2D.strokeStyle = "#000000"
      context2D.setTransform(1, 0, 0, 1, 0, 0);
      context2D.rect(this.x,this.y,this.width,this.height);
      context2D.stroke();
      context2D.restore();
  }

  public get x():number{return this.minX}
  public get y():number{return this.minY}
  public get width():number{return this.maxX - this.minX}
  public get height():number{return this.maxY - this.minY}


}
