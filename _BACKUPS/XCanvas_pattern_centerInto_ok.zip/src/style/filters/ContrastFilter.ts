class ContrastFilter extends Filter {
  constructor(intensity:number=0){
    super();
    this._intensity = intensity;
  }
  public clone():ContrastFilter{ return new ContrastFilter(this._intensity)}
  public get value():string{ return "contrast("+this._intensity+"+%)"}
}
