class SepiaFilter extends Filter {
  constructor(intensity:number=3){
    super();
    this._intensity = intensity;
  }
  public get value():string{ return "sepia("+this._intensity+"+%)"}
  public clone():SepiaFilter{return new SepiaFilter(this._intensity)}
}
