class HueRotateFilter extends Filter {
  constructor(angle:number=0){
    super();
    this._angle = angle;
  }
  public get value():string{ return "hue-rotate("+this._angle+"+%)"}
  public clone():HueRotateFilter{return new HueRotateFilter(this._angle);}
}
