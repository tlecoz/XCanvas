class PatternFill extends Pattern {

  constructor(bd:BitmapData,crop:boolean=true,applyTargetScale:boolean=false){
    super(bd,crop,applyTargetScale)
    this.styleType = "fillStyle";
  }
  public apply(context:CanvasRenderingContext2D,path:Path,target:Display2D):void{

    super.apply(context,path,target);
    if(target.fillStrokeDrawable) context.fill(path.path,this.fillPathRule);

  }
}
