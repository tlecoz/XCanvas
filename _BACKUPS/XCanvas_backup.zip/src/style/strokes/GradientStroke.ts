class GradientStroke extends Gradient {

  constructor(gradient:GradientColor,isLinear:boolean=true){
    super(gradient,isLinear)
    this.styleType = "strokeStyle";
  }

  public apply(context:CanvasRenderingContext2D,path:Path,target:Display2D):void{


    if(this.lineStyle) this.lineStyle.apply(context,path,target);

    super.apply(context,path,target);

    if(target.fillStrokeDrawable) context.stroke(path.path);


  }
}
