class GlowFilter extends DropShadowFilter {
  constructor(radius:number,color:SolidColor|string){
    super(0,0,radius,color);
  }
  public clone(cloneColor:boolean = false):GlowFilter{
    if(cloneColor) return new GlowFilter(this._radius,this._color.clone());
    return new GlowFilter(this._radius,this._color);
  }
}
