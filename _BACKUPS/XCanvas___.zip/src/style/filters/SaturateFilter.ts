class SaturatetFilter extends Filter {
  constructor(intensity:number=3){
    super();
    this._intensity = intensity;
  }
  public get value():string{ return "saturate("+this._intensity+"+%)"}
  public clone():SaturatetFilter{return new SaturatetFilter(this._intensity)}
}
