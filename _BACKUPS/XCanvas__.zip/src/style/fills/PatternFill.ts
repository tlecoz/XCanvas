class PatternFill extends Pattern {

  constructor(source:BitmapData|CanvasImageSource,crop:boolean=true,applyTargetScale:boolean=false){
    super(source,crop,applyTargetScale)
    this.styleType = "fillStyle";
  }
  public apply(context:CanvasRenderingContext2D,path:Path,target:Display2D):void{

    super.apply(context,path,target);
    if(target.fillStrokeDrawable) context.fill(path.path,this.fillPathRule);

  }
}
