class RenderEvents {
  public static RESIZE = "RESIZE";
  public static UPDATE_BEGIN = "UPDATE_BEGIN";
  public static UPDATE_END = "UPDATE_END";
}
