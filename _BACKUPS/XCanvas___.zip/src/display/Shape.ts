class Shape extends RegisterableObject {

  public x:number;
  public y:number;
  public w:number;
  public h:number;

  private renderStack:RenderStack;

  constructor(x:number,y:number,w:number,h:number,renderStack:RenderStack){
    super();
    
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.renderStack = renderStack;
  }

  public apply(context:CanvasRenderingContext2D,target:Display2D,mouseX:number=Number.MAX_VALUE,mouseY:number=Number.MAX_VALUE):boolean{

    context.save()
    context.translate(this.x * target.inverseW,this.y * target.inverseH);
    context.scale(this.w / target.width, this.h / target.height);

    var b:boolean;

    //console.log(target instanceof Display2D)

    if(target.mouseEnabled) b =  this.renderStack.updateWithHitTest(context,target,mouseX,mouseY,true);
    else {


      b =  this.renderStack.update(context,target,true);
    }
    context.restore();
    return b;
  }


}
