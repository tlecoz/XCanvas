class PatternStroke extends Pattern {

  constructor(bd:BitmapData,centerInto:boolean=true){
    super(bd,centerInto)
    this.styleType = "strokeStyle";
  }

  public apply(context:CanvasRenderingContext2D,path:Path,target:Display2D):void{

    if(this.lineStyle) this.lineStyle.apply(context,path,target);
    super.apply(context,path,target);
    if(target.fillStrokeDrawable) context.stroke(path.path);

  }
}
