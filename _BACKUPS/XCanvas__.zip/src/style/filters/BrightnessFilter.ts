class BrightnessFilter extends Filter {
  constructor(intensity:number=0){
    super();
    this._intensity = intensity;
  }
  public clone():BrightnessFilter{ return new BrightnessFilter(this._intensity)}
  public get value():string{ return "brightness("+this._intensity+"+%)"}

}
